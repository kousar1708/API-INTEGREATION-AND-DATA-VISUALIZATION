# CODTECH Internship Task 1: API Integration and Data Visualization
# By: Mohammad Kousar

import requests
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# ------------------------------
# Step 1: Fetch Data from OpenWeatherMap API
# ------------------------------

API_KEY = "your_api_key_here"  # Replace with your OpenWeatherMap API key
CITY = "London"
URL = f"https://api.openweathermap.org/data/2.5/forecast?q={CITY}&appid={API_KEY}&units=metric"

response = requests.get(URL)
data = response.json()

# ------------------------------
# Step 2: Process the JSON Data
# ------------------------------

forecast_list = data["list"]

# Extract key info
weather_data = []
for item in forecast_list:
    weather_data.append({
        "Date": item["dt_txt"],
        "Temperature (°C)": item["main"]["temp"],
        "Humidity (%)": item["main"]["humidity"],
        "Pressure (hPa)": item["main"]["pressure"],
        "Weather": item["weather"][0]["main"]
    })

# Convert to DataFrame
df = pd.DataFrame(weather_data)

# ------------------------------
# Step 3: Visualize Data
# ------------------------------

plt.figure(figsize=(10, 5))
sns.lineplot(x="Date", y="Temperature (°C)", data=df, color="orange", label="Temperature")
sns.lineplot(x="Date", y="Humidity (%)", data=df, color="blue", label="Humidity")
plt.title(f"Weather Forecast Trends for {CITY}")
plt.xticks(rotation=45)
plt.legend()
plt.tight_layout()
plt.show()

# Pie chart of weather types
plt.figure(figsize=(6, 6))
df["Weather"].value_counts().plot.pie(autopct="%1.1f%%", colors=sns.color_palette("pastel"))
plt.title(f"Weather Type Distribution for {CITY}")
plt.ylabel("")
plt.show()

# ------------------------------
# Step 4: Save Data
# ------------------------------

df.to_csv("weather_data.csv", index=False)
print("✅ Task completed! Data saved to 'weather_data.csv'")
