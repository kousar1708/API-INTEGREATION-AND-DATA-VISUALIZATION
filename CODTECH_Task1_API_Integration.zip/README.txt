# CODTECH Internship Task 1: API Integration and Data Visualization

## Overview
This project fetches weather data from the OpenWeatherMap API and visualizes it using Matplotlib and Seaborn.

## Requirements
- Python 3.x
- Libraries: requests, pandas, matplotlib, seaborn

## How to Run
1. Get your free API key from [OpenWeatherMap](https://openweathermap.org/api)
2. Replace `your_api_key_here` in the script with your actual key.
3. Run the script in Jupyter Notebook, VS Code, or Google Colab.
4. The script generates:
   - Line chart (Temperature and Humidity trend)
   - Pie chart (Weather distribution)
   - CSV file (`weather_data.csv`)

## Files
- `api_data_visualization.py` → Main Python script
- `weather_data.csv` → Output data file (after running)
